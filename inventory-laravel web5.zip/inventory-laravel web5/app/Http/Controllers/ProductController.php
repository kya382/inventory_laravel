<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->query('search');
        $categoryId = $request->query('category_id');
        $sort = $request->query('sort', 'latest');

        $products = Product::with('category')
            ->when($search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('sku', 'like', "%{$search}%")
                      ->orWhere('name', 'like', "%{$search}%");
                });
            })
            ->when($categoryId, function ($query, $categoryId) {
                $query->where('category_id', $categoryId);
            })
            ->when($sort === 'name', function ($query) {
                $query->orderBy('name', 'asc');
            })
            ->when($sort === 'price_asc', function ($query) {
                $query->orderBy('price', 'asc');
            })
            ->when($sort === 'price_desc', function ($query) {
                $query->orderBy('price', 'desc');
            })
            ->when($sort === 'latest', function ($query) {
                $query->latest();
            })
            ->paginate(5)
            ->withQueryString();

        $categories = Category::all();

        return view('products', compact(
            'products',
            'categories',
            'search',
            'categoryId',
            'sort'
        ));
    }

    public function store(Request $request)
    {
        $request->validate([
            'sku' => 'required|string|max:255|unique:products,sku',
            'name' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'minimum_stock' => 'required|integer|min:0',
        ]);

        Product::create([
            'sku' => $request->sku,
            'name' => $request->name,
            'category_id' => $request->category_id ?: null,
            'price' => $request->price,
            'stock' => $request->stock,
            'minimum_stock' => $request->minimum_stock,
        ]);

        return redirect('/products')
            ->with('success', 'Barang berhasil ditambahkan.');
    }

    public function edit(Product $product)
    {
        $categories = Category::all();

        return view('products_edit', compact('product', 'categories'));
    }

    public function update(Request $request, Product $product)
    {
        $request->validate([
            'sku' => [
                'required',
                'string',
                'max:255',
                Rule::unique('products', 'sku')->ignore($product->id),
            ],
            'name' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'price' => 'required|numeric|min:0',
            'stock' => 'required|integer|min:0',
            'minimum_stock' => 'required|integer|min:0',
        ]);

        $product->update([
            'sku' => $request->sku,
            'name' => $request->name,
            'category_id' => $request->category_id ?: null,
            'price' => $request->price,
            'stock' => $request->stock,
            'minimum_stock' => $request->minimum_stock,
        ]);

        return redirect('/products')
            ->with('success', 'Barang berhasil diperbarui.');
    }

    public function destroy(Product $product)
    {
        $product->delete();

        return redirect('/products')
            ->with('success', 'Barang berhasil dihapus.');
    }
}
