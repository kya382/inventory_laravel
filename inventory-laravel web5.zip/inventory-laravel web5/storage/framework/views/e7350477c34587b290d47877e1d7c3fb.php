
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Barang - Inventory Web 5</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #ddd;
        }

        h1 { color: #2563eb; }

        input, select {
            width: 100%;
            padding: 10px;
            margin: 8px 0 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button, .button {
            display: inline-block;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background: #2563eb;
            color: white;
            text-decoration: none;
            cursor: pointer;
        }

        .back { background: #64748b; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th { background: #2563eb; color: white; }

        .message {
            background: #dcfce7;
            padding: 12px;
            margin: 15px 0;
            border-radius: 5px;
        }

        .error { color: #dc2626; }

        .table-wrap { overflow-x: auto; }

        .filter-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto auto;
            gap: 10px;
            align-items: center;
            margin-top: 20px;
        }

        .filter-form input,
        .filter-form select {
            margin: 0;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .pagination-links {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .pagination-links a,
        .pagination-links span {
            display: inline-block;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #2563eb;
        }

        .pagination-links span {
            background: #2563eb;
            color: white;
        }

        @media (max-width: 750px) {
            body { padding: 12px; }
            .container { padding: 15px; }
            .filter-form { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>
<div class="container">
    <h1>Kelola Barang</h1>
    <a href="/dashboard" class="button back">Kembali</a>

    <form action="<?php echo e(url('/products')); ?>" method="GET" class="filter-form">
        <input
            type="text"
            name="search"
            value="<?php echo e($search ?? ''); ?>"
            placeholder="Cari kode atau nama barang..."
        >

        <select name="category_id">
            <option value="">Semua kategori</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"
                    <?php if(($categoryId ?? '') == $category->id): echo 'selected'; endif; ?>>
                    <?php echo e($category->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="sort">
            <option value="latest" <?php if(($sort ?? 'latest') === 'latest'): echo 'selected'; endif; ?>>
                Terbaru
            </option>
            <option value="name" <?php if(($sort ?? '') === 'name'): echo 'selected'; endif; ?>>
                Nama A-Z
            </option>
            <option value="price_asc" <?php if(($sort ?? '') === 'price_asc'): echo 'selected'; endif; ?>>
                Harga terendah
            </option>
            <option value="price_desc" <?php if(($sort ?? '') === 'price_desc'): echo 'selected'; endif; ?>>
                Harga tertinggi
            </option>
        </select>

        <button type="submit">Terapkan</button>
        <a href="<?php echo e(url('/products')); ?>" class="button back">Reset</a>
    </form>

    <?php if(session('success')): ?>
        <div class="message"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="error">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <h2>Tambah Barang</h2>

    <form action="<?php echo e(url('/products')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Kode Barang (SKU)</label>
        <input type="text" name="sku" value="<?php echo e(old('sku')); ?>"
               placeholder="Contoh: BRG001" required>

        <label>Nama Barang</label>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>"
               placeholder="Masukkan nama barang" required>

        <label>Kategori</label>
        <select name="category_id">
            <option value="">Pilih kategori (opsional)</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"
                    <?php if(old('category_id') == $category->id): echo 'selected'; endif; ?>>
                    <?php echo e($category->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Harga</label>
        <input type="number" name="price" min="0" step="0.01"
               value="<?php echo e(old('price', 0)); ?>" required>

        <label>Stok</label>
        <input type="number" name="stock" min="0"
               value="<?php echo e(old('stock', 0)); ?>" required>

        <label>Stok Minimum</label>
        <input type="number" name="minimum_stock" min="0"
               value="<?php echo e(old('minimum_stock', 5)); ?>" required>

        <button type="submit">Simpan Barang</button>
    </form>

    <h2>Daftar Barang</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Stok Minimum</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($products->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($product->sku); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category->name ?? '-'); ?></td>
                        <td>Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                        <td>
                            <?php echo e($product->stock); ?>


                            <?php if($product->stock <= $product->minimum_stock): ?>
                                <br>
                                <span style="color: #dc2626; font-weight: bold;">
                                    Stok Menipis!
                                </span>
                            <?php else: ?>
                                <br>
                                <span style="color: #16a34a; font-weight: bold;">
                                    Stok Aman
                                </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($product->minimum_stock); ?></td>
                        <td>
                            <a href="<?php echo e(url('/products/' . $product->id . '/edit')); ?>"
                               class="button">Edit</a>

                            <form action="<?php echo e(url('/products/' . $product->id)); ?>"
                                  method="POST"
                                  style="display:inline;"
                                  onsubmit="return confirm('Yakin ingin menghapus barang ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" style="background:#dc2626;">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" style="text-align:center">
                            Belum ada data barang.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <div>
            Menampilkan <?php echo e($products->firstItem() ?? 0); ?>–<?php echo e($products->lastItem() ?? 0); ?>

            dari <?php echo e($products->total()); ?> barang
        </div>

        <div class="pagination-links">
            <?php if($products->onFirstPage()): ?>
                <a style="color:#999;">Sebelumnya</a>
            <?php else: ?>
                <a href="<?php echo e($products->previousPageUrl()); ?>">Sebelumnya</a>
            <?php endif; ?>

            <?php $__currentLoopData = $products->getUrlRange(1, $products->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $products->currentPage()): ?>
                    <span><?php echo e($page); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($products->hasMorePages()): ?>
                <a href="<?php echo e($products->nextPageUrl()); ?>">Berikutnya</a>
            <?php else: ?>
                <a style="color:#999;">Berikutnya</a>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\inventory-laravel web5\resources\views/products.blade.php ENDPATH**/ ?>