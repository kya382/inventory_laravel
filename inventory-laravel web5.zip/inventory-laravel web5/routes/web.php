<?php
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/login', function () {
    return view('login');
})->name('login');

Route::post('/login', [AuthController::class, 'login'])->name('login.process');


Route::get('/dashboard', function () {
    $totalBarang = \App\Models\Product::count();

    $totalStok = \App\Models\Product::sum('stock');

    $stokMenipis = \App\Models\Product::whereColumn(
        'stock',
        '<=',
        'minimum_stock'
    )->count();

    return view('dashboard', compact(
        'totalBarang',
        'totalStok',
        'stokMenipis'
    ));
})->middleware('auth');


Route::post('/logout', function (Request $request) {
    auth()->logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect('/login');
})->middleware('auth');
Route::get('/products', [ProductController::class, 'index'])
    ->middleware('auth');

Route::post('/products', [ProductController::class, 'store'])
    ->middleware('auth');

Route::get('/categories', [CategoryController::class, 'index'])
    ->middleware('auth');

Route::post('/categories', [CategoryController::class, 'store'])
    ->middleware('auth');
    
    Route::get('/products/{product}/edit', [ProductController::class, 'edit'])
    ->middleware('auth');

Route::put('/products/{product}', [ProductController::class, 'update'])
    ->middleware('auth');

Route::delete('/products/{product}', [ProductController::class, 'destroy'])
    ->middleware('auth');