
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Inventory</title>

    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            color: #333;
        }

        header {
            background: #e63946;
            color: white;
            padding: 18px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        main {
            padding: 30px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
            margin: 25px 0;
        }

        .card {
            background: white;
            padding: 24px;
            border-radius: 10px;
            box-shadow: 0 3px 12px #0000000d;
        }

        .card h3 {
            margin-top: 0;
            color: #555;
        }

        .number {
            font-size: 30px;
            font-weight: bold;
            color: #e63946;
        }

        .button {
            display: inline-block;
            margin: 8px 8px 0 0;
            padding: 10px 16px;
            background: #e63946;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        button {
            background: white;
            color: #e63946;
            border: 0;
            padding: 9px 14px;
            border-radius: 5px;
            cursor: pointer;
        }

        @media (max-width: 700px) {
            .cards {
                grid-template-columns: 1fr;
            }

            main {
                padding: 18px;
            }
        }
    </style>
</head>
<body>
    <header>
        <strong>Inventory Web 5</strong>

        <form action="/logout" method="POST">
            @csrf
            <button type="submit">Keluar</button>
        </form>
    </header>

    <main>
        <h2>Dashboard</h2>
        <p>Selamat datang di Sistem Informasi Inventori.</p>
        <p>Kelola data barang dan stok dengan lebih mudah.</p>

        <div class="cards">
            <div class="card">
                <h3>Jenis Barang</h3>
                <div class="number">{{ $totalBarang }}</div>
                <p>Jumlah data barang yang tersimpan.</p>
            </div>

            <div class="card">
                <h3>Total Stok</h3>
                <div class="number">{{ $totalStok }}</div>
                <p>Jumlah seluruh stok barang.</p>
            </div>

            <div class="card">
                <h3>Stok Menipis</h3>
                <div class="number">{{ $stokMenipis }}</div>
                <p>Barang dengan stok sama dengan atau di bawah batas minimum.</p>
            </div>
        </div>

        <div class="card">
            <h3>Menu Pengelolaan</h3>
            <a class="button" href="/products">Kelola Barang</a>
            <a class="button" href="/categories">Kelola Kategori</a>
        </div>
    </main>
</body>
</html>
